<footer class="footer text-center">
    All Rights Reserved by AdminBite admin. Designed and Developed by Victoria and Yves</a>.
</footer><?php /**PATH /home/yves/laravelspace/Community/resources/views/share/footer.blade.php ENDPATH**/ ?>