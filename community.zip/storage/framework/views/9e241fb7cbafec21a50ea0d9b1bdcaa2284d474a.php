<aside class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">

                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(route('home')); ?>" aria-expanded="false">
                        <i class="fa fa-home"></i>
                        <span class="hide-menu">Accueil</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(route('listS')); ?>" aria-expanded="false">
                        <i class="fas fa-bullhorn"></i>
                        <span class="hide-menu">Campagnes</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(route('listMembre')); ?>" aria-expanded="false">
                        <i class="fa fa-users"></i>
                        <span class="hide-menu">Membres</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(route('listCommunaute')); ?>" aria-expanded="false">
                        <i class="fa fa-users"></i>
                        <span class="hide-menu">Communautés</span>
                    </a>
                </li>
                <?php if(Auth::user()->type != 1 && Auth::user()->type != 3): ?>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(route('updateCommunauteView',['id'=>8])); ?>" aria-expanded="false">
                        <i class="fa fa-cog"></i>
                        <span class="hide-menu">Paramètre</span>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside><?php /**PATH /home/yves/laravelspace/Community/resources/views/share/left-sidebar.blade.php ENDPATH**/ ?>