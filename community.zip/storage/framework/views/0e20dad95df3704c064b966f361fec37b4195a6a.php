<script src="<?php echo e(asset('/assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="<?php echo e(asset('/assets/libs/popper.js/dist/umd/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/libs/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<!-- apps -->
<script src="<?php echo e(asset('/dist/js/app.min.js')); ?>"></script>
<script src="<?php echo e(asset('/dist/js/app.init.dark.js')); ?>"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="<?php echo e(asset('/assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js')); ?>"></script>
<!--Menu sidebar -->
<script src="<?php echo e(asset('/dist/js/sidebarmenu.js')); ?>"></script>
<!--Custom JavaScript -->
<script src="<?php echo e(asset('/dist/js/custom.min.js')); ?>"></script><?php /**PATH /home/yves/laravelspace/Community/resources/views/share/scripts.blade.php ENDPATH**/ ?>