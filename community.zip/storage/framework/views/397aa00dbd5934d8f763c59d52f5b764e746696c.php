
<?php $__env->startSection('title','Liste campagne - Community'); ?>
<?php $__env->startSection('bread'); ?>
    <div class="row">
        <div class="col-3 align-self-center">
            <h4 class="page-title titre_white">Liste des Campagnes(<?php echo e($items->total()); ?>)</h4>
            <div class="d-flex align-items-center">

            </div>
        </div>

    <?php if(Auth::user()->type != 1 || Auth::user()->type != 3): ?>
        <div class="col-9 text-right">
            
            
            
            <div class="d-inline-block no-block justify-content-end align-items-center">
                <a href="<?php echo e(route('addS')); ?>" class="btn btn-pure nouvel">Nouvelle Campagne</a>
            </div>
        </div>
    <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <!-- Column -->
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4">
                <div class="card">
                <?php if(Auth::user()->type != 1): ?>
                    <a class="m-2 text-muted waves-effect waves-dark pro-pic" href="" data-toggle="dropdown" aria-haspopup="true"
                       aria-expanded="false">
                        <i class="fa fa-ellipsis-v" style="font-size:16px"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right user-dd animated flipInY">
                        <span class="with-arrow">
                            <span class="bg-primary"></span>
                        </span>
                        <a class="dropdown-item" href="<?php echo e(route('listRecense',['id'=>$item->id])); ?>"> Afficher</a>
                        <?php if(Auth::user()->type == 2): ?>
                            <a class="dropdown-item" href="<?php echo e(route('uploadPVView',['id'=>$item->id])); ?>"> Charger le pv de cette campagne</a>
                        <?php endif; ?>
                        <a class="dropdown-item" href="<?php echo e(route('addRecense',['id'=>$item->id])); ?>" target="_blank"> Récenser maintenant</a>
                        <a class="dropdown-item" href="<?php echo e(route('updateView',['id'=>$item->id])); ?>"> Modifier</a>
                        <a class="dropdown-item" href="<?php echo e(route('deleteS',['id'=>$item->id])); ?>"> Supprimer</a>
                    </div>
                <?php endif; ?>
                    <div class="card-body">
                        <center><h3><?php echo e($item->libelle); ?></h3></center>
                        <small class="text-center"><?php echo e($item->description); ?></small><br>
                        <div class="d-flex no-block align-items-center m-b-15">
                            <span><i class="fa fa-calendar">&nbsp;<?php echo e($item->beginAt); ?></i></span>
                            <div class="ml-auto">
                                <span><i class="fa fa-calendar">&nbsp;<?php echo e($item->endAt); ?></i></span>
                            </div>
                        </div>
                        <div class="d-flex no-block align-items-center m-b-15">
                            <?php if(Auth::user()->type == 1 && $item->path != 'NULL' && $item->path != ""): ?>
                                <a style="background: #eeeeee;color:#000" class="btn col-md-12" href="<?php echo e(route('download',['id'=>$item->id])); ?>"> Charger le pv de cette campagne</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- Column -->
    </div>
    <div style="margin-top:8%">
        <nav aria-label="Page navigation example" class="text-center">
            <?php echo e($items->links()); ?>

        </nav>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yves/laravelspace/community/resources/views/sensibilisation/listSensibilisation.blade.php ENDPATH**/ ?>