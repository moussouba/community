
<?php $__env->startSection('title','Liste communauté - Community'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="page-breadcrumb">
                        <div class="row">
                            <div class="col-5 align-self-center">
                                <h4 class="page-title">Communautés enregistrées (<?php echo e($items->total()); ?>)</h4>
                                <div class="d-flex align-items-center">

                                </div>
                            </div>
                            <?php if(Auth::user()->type == 1): ?>
                            <div class="col-7 align-self-center">
                                <div class="d-flex no-block justify-content-end align-items-center">
                                    <a href="<?php echo e(route('addCommunauteView')); ?>" class="btn btn-pure nouvel">Créer communauté</a>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table id="demo-foo-addrow" class="table m-t-30 no-wrap table-hover contact-list" data-page-size="10">
                            <thead class="bg-inverse text-white">
                            <tr>
                                <th>Communauté</th>
                                <th>Localité</th>
                                <th>Responsable</th>
                                <th>Numéro</th>
                                <th>lien whatsApp</th>
                                <th>Total membre</th>
                                <?php if(Auth::user()->type == 1): ?>
                                <th>Actions</th>
                                <?php endif; ?>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->nom); ?></td>
                                    <td><?php echo e($item->localite); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $item->responsable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($rp->name); ?> <?php echo e($rp->prenom); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <?php $__currentLoopData = $item->responsable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($rp->tel); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><a href="<?php echo e($item->lien); ?>" target="_blank"><?php echo e($item->lien); ?></a></td>
                                    <td><?php echo e($item->membres->count()); ?></td>
                                    <?php if(Auth::user()->type == 1): ?>
                                        <td>
                                            <a href="<?php echo e(route('updateCommunauteView', ['id'=>$item->id])); ?>" class="btn btn-xs btn-pure nouvel">Modifier</a>
                                            <a href="<?php echo e(route('deleteCommunaute', ['id'=>$item->id])); ?>" class="btn btn-xs btn-pure nouvel">Supprimer</a>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div style="margin-top:8%">
        <nav aria-label="Page navigation example" class="text-center">
            <?php echo e($items->links()); ?>

        </nav>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yves/laravelspace/community/resources/views/communaute/listCommunaute.blade.php ENDPATH**/ ?>