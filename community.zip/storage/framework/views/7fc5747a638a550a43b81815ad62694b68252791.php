<?php $__env->startSection('title','Liste membre - Community'); ?>
<?php $__env->startSection('bread'); ?>
    <div class="row">
        <div class="col-5 align-self-center">
            <h4 class="page-title titre_white">Total Membres (<?php echo e($user->total()); ?>)</h4>
            <div class="d-flex align-items-center">

            </div>
        </div>
        <?php if(Auth::user()->type != 3): ?>
        <div class="col-7 align-self-center">
            <div class="d-flex no-block justify-content-end align-items-center">
                <a href="<?php echo e(route('registerWiew')); ?>" class="btn btn-pure nouvel">Nouveau membre</a>
            </div>
        </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-4">
                <div class="card cadre">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-9" style="vertical-align:bottom">
                                <h4 class="font-light"><?php echo e($usr->name); ?> <?php echo e($usr->prenom); ?> 
                                <?php if($usr->type == 2): ?> 
                                    <img width="14" src="<?php echo e(asset('/assets/images/rating/star-on.png')); ?>" alt="">
                                <?php endif; ?>
                                <?php if($usr->type == 3): ?>
                                    <img width="14" src="<?php echo e(asset('/assets/images/rating/star-off.png')); ?>" alt="">
                                <?php endif; ?>
                                </h4>
                                <small class="text-success">
                                        <?php echo e($usr->communaute['nom']); ?>

                                </small>
                            </div>
                            <div class="col-md-3">
                                <img style="border:3px solid rgba(49,230,0,0.7);cursor:pointer" width="50" src="<?php echo e(asset('/assets/images/users/user.png')); ?>" alt="" class="rounded-circle">
                            </div>
                        </div>
                        <div class="row p-t-10 p-b-10">
                            <div class="col text-left">
                                <h6 class="text-muted"><?php echo e($usr->sexe); ?></h6>
                                <h6 class="text-muted"><?php echo e($usr->tel); ?></h6>
                                <h6 class="text-muted"><?php echo e($usr->email); ?></h6>
                                <h6 class="text-muted"><?php echo e($usr->localite); ?></h6>
                                <h6 class="text-muted"><?php echo e($usr->niveau); ?> ( <?php echo e($usr->specialite); ?> )</h6>
                                <i>Membre depuis: <b><?php echo e($usr->created_at); ?></b></i><br>
                                <?php if(Auth::user()->type != 1 && Auth::user()->type != 3): ?>
                                    <small>Ce membre n'est plus actif ? <a href="<?php echo e(route('deleteMembre',['id'=>$usr->id])); ?>" style="cursor:pointer" class="text-danger"><u>  supprimez-le</u></a></small>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <div class="row">
        <div style="margin-top:8%">
            <nav aria-label="Page navigation example" class="text-center">
                <?php echo e($user->links()); ?>

            </nav>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yves/laravelspace/community/resources/views/membre/listMembre.blade.php ENDPATH**/ ?>