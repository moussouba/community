<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Ajout <?php echo e($test); ?></h4> <br>
                    <h6 class="text-danger card-subtitle">Tous les champs sont requis <b>(*)</b></h6>
                </div>
                <hr class="m-t-0">
                <form class="form-horizontal r-separator" method="POST" action="<?php echo e(route('register')); ?>">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-6 col-lg-6">
                                <div class="form-group row">
                                    <label for="inputEmail0" class="col-sm-3 text-left control-label col-form-label"> Nom</label>
                                    <div class="col-sm-9">
                                        <input type="text" name="name" value="<?php echo e(old('name')); ?>" required class="<?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> form-control" id="inputEmail0" placeholder="Nom du membre">
                                        <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        <input type="hidden" name="_token" class="form-control" value="<?php echo e(csrf_token()); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-6">
                                <div class="form-group row">
                                    <label for="inputEmail1" class="col-sm-3 text-left control-label col-form-label"> Prenom(s)</label>
                                    <div class="col-sm-9">
                                        <input type="text" name="prenom" value="<?php echo e(old('prenom')); ?>" required class="<?php if ($errors->has('prenom')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('prenom'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> form-control" id="inputEmail1" placeholder="Prenom du membre">
                                        <?php if ($errors->has('prenom')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('prenom'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-6">
                                <div class="form-group row">
                                    <label for="inputEmail4" class="col-sm-3 text-left control-label col-form-label"> Telephone</label>
                                    <div class="col-sm-9">
                                        <input type="text" name="tel" value="" class="form-control" id="inputEmail4" placeholder="Telephone du membre">
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-6">
                                <div class="form-group row">
                                    <label for="inputEmail6" class="col-sm-3 text-left control-label col-form-label"> E-mail</label>
                                    <div class="col-sm-9">
                                        <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> form-control" id="inputEmail6" placeholder="E-mail du membre">
                                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-6">
                                <div class="form-group row">
                                    <label for="inputEmail2" class="col-sm-3 text-left control-label col-form-label"> Sexe</label>
                                    <div class="col-sm-9">
                                        <select class="col-md-12 <?php if ($errors->has('sexe')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sexe'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> " name="sexe" id="2">
                                            <option selected value="Masculin">Masculin</option>
                                            <option value="Feminin">Feminin</option>
                                        </select>
                                        <?php if ($errors->has('sexe')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sexe'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-6">
                                <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-3 text-left control-label col-form-label"> Localité</label>
                                    <div class="col-sm-9">
                                        <select class="col-md-12 <?php if ($errors->has('localite')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('localite'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> " name="localite" id="3">
                                            <option selected value="Abidjan - Koumassi">Abidjan - Koumassi</option>
                                            <option value="Abidjan - Abobo">Abidjan - Abobo</option>
                                        </select>
                                        <?php if ($errors->has('localite')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('localite'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-6">
                                <div class="form-group row">
                                    <label for="inputEmail7" class="col-sm-3 text-left control-label col-form-label"> Niveau</label>
                                    <div class="col-sm-9">
                                        <select class="col-md-12 <?php if ($errors->has('niveau')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('niveau'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> " name="niveau" id="7">
                                            <option selected value="Licence 1">Licence 1</option>
                                            <option value="Licence 2">Licence 2</option>
                                            <option value="Licence 3">Licence 3</option>
                                            <option value="Master 1">Master 1</option>
                                            <option value="Master 2">Master 2</option>
                                        </select>
                                        <?php if ($errors->has('niveau')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('niveau'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-6">
                                <div class="form-group row">
                                    <label for="inputEmail8" class="col-sm-3 text-left control-label col-form-label"> Spécialité</label>
                                    <div class="col-sm-9">
                                        <select class="col-md-12 <?php if ($errors->has('specialite')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('specialite'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> " name="specialite" id="8">
                                            <option selected value="RSI">RSI</option>
                                            <option value="DAS">DAS</option>
                                            <option value="BD">BD</option>
                                            <option value="MMX">MMX</option>
                                            <option value="CMD">CMD</option>
                                            <option value="CD">CD</option>
                                        </select>
                                        <?php if ($errors->has('specialite')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('specialite'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php if(Auth::user()->type == 1): ?>                            
                            <div class="col-sm-6 col-lg-6">
                                <div class="form-group row">
                                    <label for="inputEmail10" class="col-sm-3 text-left control-label col-form-label"> Type de compte</label>
                                    <div class="col-sm-9">
                                        <select class="col-md-12  <?php if ($errors->has('type')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('type'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="type" id="10">
                                            <option selected value="1">Admin</option>
                                            <option selected value="2">Président de la communauté</option>
                                        </select>
                                        <?php if ($errors->has('type')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('type'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-6 col-lg-6">
                                <div class="form-group row">
                                    <label for="inputEmail9" class="col-sm-3 text-left control-label col-form-label"> Communauté</label>
                                    <div class="col-sm-9">
                                        <select class="col-md-12 <?php if ($errors->has('communaute')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('communaute'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="communaute" id="9">
                                            <option selected value="1">Aucune communauté</option>
                                        </select>
                                        <?php if ($errors->has('communaute')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('communaute'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            <div class="col-sm-6 col-lg-6">
                                <div class="form-group row">
                                    <label for="inputEmail14" class="col-sm-3 text-left control-label col-form-label"> Mot de passe</label>
                                    <div class="col-sm-9">
                                        <input type="password" name="password" value="" class="<?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> form-control" id="inputEmail14" placeholder="Mot de passe du membre">
                                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-6">
                                <div class="form-group row">
                                    <label for="inputEmail124" class="col-sm-3 text-left control-label col-form-label"> Mot de passe</label>
                                    <div class="col-sm-9">
                                        <input type="password" name="password_confirmation" value="" class="form-control" id="inputEmail124" placeholder="Mot de passe du membre">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="p-3">
                        <div class="form-group m-b-0 text-right">
                            <button type="submit" class="btn btn-pure "><?php echo e(isset($items->nom)? 'Modifier maintenant ':'Ajouter maintenant '); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yves/laravelspace/Community/resources/views/auth/register.blade.php ENDPATH**/ ?>