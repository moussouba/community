<?php if(Session::has('success')): ?>
    <div class="container">
        <div class="row">
            <div class=" col-md-12 col-sm-12 col-lg-12 alert alert-success alert-rounded">
                <?php echo e(Session::get('success')); ?>

            </div>
        </div>
    </div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
    <div class="container">
        <div class="row">
            <div class=" col-md-12 col-sm-12 col-lg-12 alert alert-danger alert-rounded">
                <?php echo e(Session::get('error')); ?>

            </div>
        </div>
    </div>
<?php endif; ?><?php /**PATH /home/yves/laravelspace/community/resources/views/share/alert.blade.php ENDPATH**/ ?>