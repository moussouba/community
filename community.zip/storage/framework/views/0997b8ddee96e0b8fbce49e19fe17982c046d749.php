
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="page-breadcrumb">
                        <div class="row">
                            <div class="col-5 align-self-center">
                                <h4 class="page-title">Personnes enregistrées - <?php echo e($sensib->libelle); ?> (<?php echo e($items->total()); ?>)</h4>
                                <div class="d-flex align-items-center">

                                </div>
                            </div>
                            <div class="col-7 align-self-center">
                                <div class="d-flex no-block justify-content-end align-items-center">
                                    <a href="<?php echo e(route('addRecense',['id'=>$id])); ?>" class="btn btn-pure nouvel">Récenser maintenant</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table id="demo-foo-addrow" class="table m-t-30 no-wrap table-hover contact-list" data-page-size="10">
                            <thead class="bg-inverse text-white">
                            <tr>
                                <th>Nom</th>
                                <th>Prénom</th>
                                <th>Sexe</th>
                                <th>Email</th>
                                <th>Numéro</th>
                                <th>Niveau</th>
                                <th>Matricule</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->nom); ?></td>
                                    <td><?php echo e($item->prenom); ?></td>
                                    <td><?php echo e($item->sexe); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td><?php echo e($item->tel); ?></td>
                                    <td><?php echo e($item->niveau); ?></td>
                                    <td><?php echo e($item->matricule); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('deleteRecense', ['sensi'=>$id,'id'=>$item->id])); ?>" class="btn btn-xs btn-pure nouvel">Supprimer</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div style="margin-top:8%">
                            <nav aria-label="Page navigation example" class="text-center">
                                <?php echo e($items->links()); ?>

                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yves/laravelspace/community/resources/views/recense/listRecense.blade.php ENDPATH**/ ?>