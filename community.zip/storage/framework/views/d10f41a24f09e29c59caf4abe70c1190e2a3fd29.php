<footer class="footer text-center" style="color: #0a3c33">
    All Rights Reserved 2019. Developed by Bosser pour être boss - Koumassi</a>.
</footer><?php /**PATH /home/yves/laravelspace/community/resources/views/share/footer.blade.php ENDPATH**/ ?>