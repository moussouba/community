<?php $__env->startSection('title','Page introuvable'); ?>

<?php $__env->startSection('content'); ?>
<div class="error-box">
    <div class="error-body text-center">
        <h1 class="error-title">400</h1>
        <h3 class="text-uppercase error-subtitle">Page introuvable</h3>
        <p class="text-muted m-t-30 m-b-30">Vous essayer de trouver une page inexistante</p>
        <a href="<?php echo e(route('home')); ?>" class="btn btn-info btn-rounded waves-effect waves-light m-b-40">Retour à la page d'accueil</a> 
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yves/laravelspace/community/resources/views/errors/404.blade.php ENDPATH**/ ?>