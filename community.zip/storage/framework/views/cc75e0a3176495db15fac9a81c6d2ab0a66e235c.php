<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('/assets/images/favicon.png')); ?>">
<title>enregistrement des communauté et des étudiants</title>
<!-- Custom CSS -->
<!-- Custom CSS -->
<link href="<?php echo e(asset('/dist/css/style.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/dist/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/dist/css/icons/font-awesome/css/fontawesome.css')); ?>" rel="stylesheet"><?php /**PATH /home/yves/laravelspace/community/resources/views/share/stylesheets.blade.php ENDPATH**/ ?>