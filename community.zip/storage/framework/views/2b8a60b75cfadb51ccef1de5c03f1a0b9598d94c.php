<?php $__env->startSection('title','Non disponible'); ?>

<?php $__env->startSection('content'); ?>
<div class="error-box">
    <div class="error-body text-center">
        <h1 class="error-title">503</h1>
        <h3 class="text-uppercase error-subtitle">Site en maintenance</h3>
        <p class="text-muted m-t-30 m-b-30">Veuillez nous excusez du désagrement</p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yves/laravelspace/Community/resources/views/errors/503.blade.php ENDPATH**/ ?>