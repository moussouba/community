<script src="{{ asset('/assets/libs/jquery/dist/jquery.min.js')}}"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="{{ asset('/assets/libs/popper.js/dist/umd/popper.min.js')}}"></script>
<script src="{{ asset('/assets/libs/bootstrap/dist/js/bootstrap.min.js')}}"></script>
<!-- apps -->
<script src="{{ asset('/dist/js/app.min.js')}}"></script>
<script src="{{ asset('/dist/js/app.init.dark.js')}}"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="{{ asset('/assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js')}}"></script>
<!--Menu sidebar -->
<script src="{{ asset('/dist/js/sidebarmenu.js')}}"></script>
<!--Custom JavaScript -->
<script src="{{ asset('/dist/js/custom.min.js')}}"></script>