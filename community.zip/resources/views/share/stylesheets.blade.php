<link rel="icon" type="image/png" sizes="16x16" href="{{ asset('/assets/images/favicon.png') }}">
<title>enregistrement des communauté et des étudiants</title>
<!-- Custom CSS -->
<!-- Custom CSS -->
<link href="{{ asset('/dist/css/style.min.css') }}" rel="stylesheet">
<link href="{{ asset('/dist/css/style.css') }}" rel="stylesheet">
<link href="{{ asset('/dist/css/icons/font-awesome/css/fontawesome.css') }}" rel="stylesheet">